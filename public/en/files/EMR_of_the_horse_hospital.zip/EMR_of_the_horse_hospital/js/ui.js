$(document).ready(function(){

	userAgentCheck();
	file();
	selectLabel();
	gnb();	
	deps();
	searchPop();
	setSide();

	function userAgentCheck(){
		var userAgentCheck = function(){    
		var ua = navigator.userAgent.toString().toLowerCase();
		var agent = {};
		var $html = document.getElementsByTagName('html')[0];
		var addClassName = '';

		agent = {
				ios: (/ip(ad|hone|od)/i).test(ua),
				android: (/android/i).test(ua),
				ie : (/msie/i).test(ua) || (/trident/i).test(ua),
				msedge : (/edge/i).test(ua), // MS edge(applewekit,chrome,safari)
				firefox: (/firefox/i).test(ua),
				webkit: (/applewebkit/i).test(ua),
				chrome: (/chrome/i).test(ua),
				opera: (/opera/i).test(ua)          
		};
		
		agent.safari = (agent.webkit) && (!agent.chrome);
		agent.mobile = document.ontouchstart !== undefined && ( agent.ios || agent.android );
		agent.desktop = !(agent.ios || agent.android);
		agent.os = (navigator.appVersion).match(/(mac|win|linux)/i);
		agent.os =  agent.os ? agent.os[1].toLowerCase() : '';

		// ie 버전 체크
		if(agent.ie){
			var ieVersion = ua.match(/(msie |trident.*rv[ :])([0-9]+)/)[2];
			ieVersion = Math.floor(ieVersion);
			agent.ie = "ie ie"+ieVersion;
		}  
		
		// ms edge, chrome, safari일 경우 중복되는 값 삭제하기
		if(agent.msedge){
			agent.webkit = agent.chrome = agent.safari = false;
		} 
		
		if(agent.chrome || agent.safari){
			agent.webkit = false;
		}
		
		var reverseFn = function(){
			var classArr = [];
			for(var value in agent){
				if(agent[value]){
					if(value == 'os' || value == 'ie'){
						classArr.push(agent[value]);
					}else{
						classArr.push(value);
					}
				}
			}             
			addClassName = classArr.reverse().join(' ');
		}();
		
		$html.className = addClassName;
			   
		}(); 
	}// end userAgentCheck

	function file(){
		var fileTarget = $("#upload_btn");
		fileTarget.on("change", function(){
			if(window.FileReader){
				var filename = $(this)[0].files[0].name;
			}else{
				var filename = $(this).val().split("/").pop().split("\\").pop();//파일명만 추출
			}
			$(this).siblings(".wrap_time").children("#file_name").val(filename);
		}); 
	}// end file
	
	function selectLabel() {
	$(".select_wrap select").change(function() {
		var getText = $(this).find("option:selected").text();
		$(this).prev(".select_label").html(getText);
		});
	}// selectLabel
	
	/*gnb 메뉴*/
	function gnb(){
		var clickArea = $('.btn_gnb');
		var menu = $('.sidemenu_gnb');
		var dim = $('.dim');
		clickArea.on('click', function(){	
			menu.animate({'right':'0'}, 'easing');	
			dim.css('display','block');
			$('body').css('overflow','hidden');				
		});
		dim.on('click', function(){
			menu.animate({'right':'-600px'}, 'easing');		
			dim.css('display','none');
			$('body').css('overflow','auto');
		});
	}

	/*gnb deps 스크립트*/
	function deps(){
		var deps_01 = $('.wrap_deps .deps_01 .tit');	
		deps_01.on('click',function(e){					
			e.preventDefault();
			if(!$(this).hasClass('on')){
				$(this).addClass('on');
				$(this).next('.deps_02').show();
				$(this).parent('li').siblings('li').removeClass('active').children('.tit').removeClass('on').next('.deps_02').hide();
				$(this).parent('li').addClass('active');					
				
			}else{
				$(this).removeClass('on');
				$(this).next('.deps_02').hide();
				$(this).parent('li').removeClass('active');					
			}				
		});
	}

	/*상세검색 팝업*/
	function searchPop(){
		$('.search_s').on('click',function(){				
			$('.pop_search').bPopup({
				//modalClose : false
				opacity: 1,
				modalColor: ('#222')					
			});
			$('.b-modal').append("<div class='b-close'></div>");
		});
	}

	/*진료이력조회 문서양식관리 왼쪽사이드 메뉴 높이*/
	function setSide(){	
		var target = $('.contents.type_second.scroll.type5 .box_left_area');
		var height = $('.contents.type_second.scroll.type5 .box_right.type1').outerHeight(true);		
		target.css('height',height);		
	}
	

});




