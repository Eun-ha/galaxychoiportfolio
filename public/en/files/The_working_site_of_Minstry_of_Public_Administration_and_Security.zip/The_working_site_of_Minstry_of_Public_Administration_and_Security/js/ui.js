$(document).ready(function(){
	setSide();
	deps();
	searching_total();
});

/*aside 메뉴*/
function deps(){
	var deps_01 = $('.wrap_deps .depth_01 .tit');	
	deps_01.on('click',function(e){			
		e.preventDefault();
		if(!$(this).parent().hasClass('on')){
			$(this).parent().addClass('on');
			$(this).next('.depth_02').show();
			$(this).parent('li').siblings('li').removeClass('on').children('.tit').removeClass('on').next('.depth_02').hide();
			$(this).parent('li').addClass('on');					
			
		}else{
			$(this).parent().removeClass('on');
			$(this).next('.depth_02').hide();
			$(this).parent('li').removeClass('on');					
		}				
	});
}  

/*댓글 더보기*/
function viewMore(){
	var parents = $('.board_list.type2');
	var target = parents.children('.list');
	var clickSpot = parents.children('.wrap_btn');

	clickSpot.on('click','> button', function(){
		if(target.hasClass('on')){
			$(this).parent().siblings('.list').removeClass('on');
			$(this).html('댓글 더보기');
		}else{
			$(this).parent().siblings('.list').addClass('on');
			$(this).html('댓글 닫기');
		}
	});
}// end viewMore

/*파일찾기*/
function file(){
	var fileTarget = $("#upload_btn");
	fileTarget.on("change", function(){
		if(window.FileReader){
			var filename = $(this)[0].files[0].name;
		}else{
			var filename = $(this).val().split("/").pop().split("\\").pop();//파일명만 추출
		}
		$(this).siblings(".wrap_txt").children("#file_name").val(filename);
	}); 
}// end file

/*왼쪽사이드 메뉴 높이*/
function setSide(){	
	var sideHeight = $('.aside');
	var height = $(window).height();		
	sideHeight.css('height', height);	

	$(window).resize(function(){
		var sideHeight = $('.aside');
		var height = $(window).height();		
		sideHeight.css('height', height);	
	});
}// end setSide

/*통합검색 컨텐츠 높이*/
function setSideTotal(){	
	var sideHeight = $('.searching_total .inner_box');
	var height = $(window).height();		
	sideHeight.css('height', (height-180));	

	$(window).resize(function(){
		var sideHeight = $('.searching_total .inner_box');
		var height = $(window).height();		
		sideHeight.css('height', (height-180));	
	});
}// end setSide

//찬성-반대 우측 fix 메뉴
function fixMenu(){
	$(window).scroll(function(){
		var fixTop =  $('.board_view .board_view_conts .conts').offset().top;
		var clearTop = $('.board_view .wrap_btn').offset().top;
		var position = $(window).scrollTop();
		var target = $('.targetFixed');

		if(position < fixTop || position >= clearTop){
			target.removeClass('fixed');
		}else{
			target.addClass('fixed');
		}
	});
}// end fixMenu

/*왼쪽사이드 스크롤 높이*/
function sideScroll(){	
	var wHeight = $(window).height();	
	var rmHeight = $('.aside .menu_r .inner_top').outerHeight();
	var scrollheight = (wHeight - rmHeight);	

	$('.asideSlimscr').slimScroll({
			height: scrollheight
	}); // scrollbar fn - slimescroll plugin

	$(window).resize(function(){
		var wHeight = $(window).height();	
		var rmHeight = $('.aside .menu_r .inner_top').outerHeight();
		var scrollheight = (wHeight - rmHeight);	

		$('.asideSlimscr').slimScroll({
				height: scrollheight
		}); // scrollbar fn - slimescroll plugin
	});
	
}// end setSide

// 탭
function tab(){
	$('.tab').on('click', 'a', function(){
		var idx = $(this).parent().index();
		$(this).parent().addClass('on').siblings().removeClass('on')
		.parent().siblings('.search_form').hide().eq(idx).show();
	});
}// end tab

//로딩바 보이기
function loadingShow(msg){
	if(msg !=undefined && msg!=null && $.trim(msg).length>0) {
		$('div.wrap_loading div.guide').html(msg);	
	}
	
	$('.wrap_loading').show();
	var target = $('.wrap_loading .guide');
	var marginL = -(target.outerWidth()/2);
	target.css('margin-left', marginL);
	$('html , body').css('overflow','hidden');
}
//로딩바 숨기기
function loadingHide(){
	$('.wrap_loading').hide();
	$('html , body').css('overflow','auto');
}

// on 클래스 더하기 :: 좋아요하트
function addClassOn(){
	$('.ico_likes').on('click', function(){
		if($(this).hasClass('on')){
			$(this).removeClass('on');
		}else{
			$(this).addClass('on');
		}
		
	});
}

// 토글 :: 찬성반대기능
function toggle(){
	$('.box_type2.type2 a').on('click', function(){
		$(this).addClass('on').siblings('a').removeClass('on');
	});
}

//통합검색
function searching_total(){
	$('.box_searching > div').on('click', 'a', function(){
		if($(this).find('img').attr('alt') == '검색 열기'){
			$(this).parents('.box_searching').addClass('active');
			$(this).next().fadeIn(300);
		} else {
			$(this).parents('.box_searching').removeClass('active');
			$(this).parent().fadeOut(300);
		};
	});
}






		
		



